package com.example.demo.model;

public class DeliveryAddress {
	private String streetnName;
	private int streetNo;
	public String getStreetnName() {
		return streetnName;
	}
	public void setStreetnName(String streetnName) {
		this.streetnName = streetnName;
	}
	public int getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(int streetNo) {
		this.streetNo = streetNo;
	}
	
	
}
