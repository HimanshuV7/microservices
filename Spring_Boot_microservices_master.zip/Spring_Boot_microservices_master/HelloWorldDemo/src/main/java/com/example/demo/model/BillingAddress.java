package com.example.demo.model;

public class BillingAddress {
	private String streetnName;
	private int streetNo;
	
	public String getStreetnName() {
		return streetnName;
	}
	public void setStreetnName(String streetnName) {
		this.streetnName = streetnName;
	}
	public int getStreetNo() {
		return streetNo;
	}
	public void setStreetNo(int streetNo) {
		this.streetNo = streetNo;
	}
	
	
}
