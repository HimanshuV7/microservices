package com.orderservice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderService2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
