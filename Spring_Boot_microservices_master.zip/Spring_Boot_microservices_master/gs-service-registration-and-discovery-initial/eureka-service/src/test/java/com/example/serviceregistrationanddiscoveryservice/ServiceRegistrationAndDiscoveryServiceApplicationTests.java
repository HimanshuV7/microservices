package com.example.serviceregistrationanddiscoveryservice;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ServiceRegistrationAndDiscoveryServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
