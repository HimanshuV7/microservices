package com.amdocs.ribboneurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbonEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
